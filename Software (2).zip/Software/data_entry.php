<!DOCTYPE html>
<html>
<head>
    <title>Data Entry - St Alphonsus School</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Data Entry</h1>

    <h2>Enter Class Details</h2>
    <form method="POST" action="insert_data.php">
        Class Name: <input type="text" name="class_name" required><br>
        Capacity: <input type="number" name="capacity" required><br>
        <input type="submit" name="submit_class" value="Add Class">
    </form>

    <h2>Enter Teacher Details</h2>
    <form method="POST" action="insert_data.php">
        Name: <input type="text" name="teacher_name" required><br>
        Address: <input type="text" name="teacher_address" required><br>
        Phone: <input type="text" name="teacher_phone" required><br>
        Salary: <input type="number" step="0.01" name="teacher_salary" required><br>
        Background Check Passed: <input type="checkbox" name="background_check"><br>
        <input type="submit" name="submit_teacher" value="Add Teacher">
    </form>

    <h2>Enter Pupil Details</h2>
    <form method="POST" action="insert_data.php">
        Name: <input type="text" name="pupil_name" required><br>
        Address: <input type="text" name="pupil_address" required><br>
        Medical Info: <textarea name="medical_info"></textarea><br>
        Class ID: <input type="number" name="class_id" required><br>
        <input type="submit" name="submit_pupil" value="Add Pupil">
    </form>

    <h2>Enter Parent/Guardian Details</h2>
    <form method="POST" action="insert_data.php">
        Name: <input type="text" name="parent_name" required><br>
        Address: <input type="text" name="parent_address" required><br>
        Email: <input type="email" name="parent_email" required><br>
        Phone: <input type="text" name="parent_phone" required><br>
        <input type="submit" name="submit_parent" value="Add Parent">
    </form>

    <br><a href="index.php">Back to Home</a>
</body>
</html>
