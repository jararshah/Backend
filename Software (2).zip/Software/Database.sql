CREATE DATABASE School_db;
USE School_db;

-- Table for Classes
CREATE TABLE Classes (
    class_id INT PRIMARY KEY AUTO_INCREMENT,
    class_name VARCHAR(50) UNIQUE NOT NULL,
    capacity INT NOT NULL
);

-- Table for Teachers
CREATE TABLE Teachers (
    teacher_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    annual_salary DECIMAL(10,2) NOT NULL,
    background_check BOOLEAN DEFAULT FALSE
);

-- Table for Pupils
CREATE TABLE Pupils (
    pupil_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    medical_info TEXT,
    class_id INT,
    FOREIGN KEY (class_id) REFERENCES Classes(class_id) ON DELETE SET NULL
);

-- Table for Parents/Guardians
CREATE TABLE Parents (
    parent_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) UNIQUE NOT NULL
);

-- Junction Table for Pupil-Parent Relationship (Many-to-Many)
CREATE TABLE Pupil_Parents (
    pupil_id INT,
    parent_id INT,
    PRIMARY KEY (pupil_id, parent_id),
    FOREIGN KEY (pupil_id) REFERENCES Pupils(pupil_id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES Parents(parent_id) ON DELETE CASCADE
);

-- Assign a Teacher to a Class (One-to-One)
-- ALTER TABLE Classes ADD COLUMN teacher_id INT UNIQUE;
-- ALTER TABLE Classes ADD FOREIGN KEY (teacher_id) REFERENCES Teachers(teacher_id) ON DELETE SET NULL;



INSERT INTO Classes (class_name, capacity) VALUES 
('Reception Year', 30),
('Year One', 28),
('Year Two', 27),
('Year Three', 29),
('Year Four', 30);


INSERT INTO Teachers (name, address, phone, annual_salary, background_check) VALUES 
('John Smith', '123 Oak Street, Luton', '07512345678', 35000.00, TRUE),
('Emma Brown', '45 Maple Avenue, Luton', '07498765432', 36000.00, TRUE),
('Michael Johnson', '78 Pine Road, Luton', '07345678901', 35500.00, TRUE),
('Sarah Wilson', '9 Birch Lane, Luton', '07234567890', 37000.00, TRUE),
('David Lee', '16 Elm Street, Luton', '07123456789', 34000.00, FALSE);


INSERT INTO Pupils (name, address, medical_info, class_id) VALUES 
('Liam Turner', '21 Willow Street, Luton', 'Asthma', 1),
('Sophia Green', '32 Oak Drive, Luton', 'None', 2),
('Ethan White', '14 Chestnut Road, Luton', 'Nut Allergy', 3),
('Olivia Adams', '67 Cedar Close, Luton', 'None', 4),
('Noah Roberts', '10 Beech Crescent, Luton', 'Peanut Allergy', 5);


INSERT INTO Parents (name, address, email, phone) VALUES 
('James Turner', '21 Willow Street, Luton', 'james.turner@example.com', '07900112233'),
('Emma Green', '32 Oak Drive, Luton', 'emma.green@example.com', '07911223344'),
('Robert White', '14 Chestnut Road, Luton', 'robert.white@example.com', '07922334455'),
('Charlotte Adams', '67 Cedar Close, Luton', 'charlotte.adams@example.com', '07933445566'),
('William Roberts', '10 Beech Crescent, Luton', 'william.roberts@example.com', '07944556677');


INSERT INTO Pupil_Parents (pupil_id, parent_id) VALUES 
(1, 1), -- Liam Turner has James Turner as a parent
(2, 2), -- Sophia Green has Emma Green as a parent
(3, 3), -- Ethan White has Robert White as a parent
(4, 4), -- Olivia Adams has Charlotte Adams as a parent
(5, 5); -- Noah Roberts has William Roberts as a parent
