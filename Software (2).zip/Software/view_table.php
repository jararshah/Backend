<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "School_db";

// Connect to database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get table name from URL
if (isset($_GET['table'])) {
    $table = $_GET['table'];

    echo "<h1>Data from $table</h1>";

    $result = $conn->query("SELECT * FROM $table");

    if ($result->num_rows > 0) {
        echo "<table border='1'><tr>";
        
        // Fetch column names
        while ($field = $result->fetch_field()) {
            echo "<th>" . $field->name . "</th>";
        }
        
        echo "</tr>";
        
        // Fetch rows
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>$value</td>";
            }
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "No records found.";
    }
} else {
    echo "No table specified.";
}

$conn->close();
?>

<br><a href="view_data.php">Back to View Data</a>
