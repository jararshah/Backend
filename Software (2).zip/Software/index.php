<!DOCTYPE html>
<html>
<head>
    <title>Home - St Alphonsus School</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Welcome to St Alphonsus Primary School Database</h1>
    <ul>
        <li><a href="data_entry.php">Data Entry</a></li>
        <li><a href="view_data.php">View Data</a></li>
    </ul>
</body>
</html>
