<!DOCTYPE html>
<html>
<head>
    <title>View Data - St Alphonsus School</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>View Data</h1>

    <h2>Classes</h2>
    <a href="view_table.php?table=Classes">View Classes</a>

    <h2>Teachers</h2>
    <a href="view_table.php?table=Teachers">View Teachers</a>

    <h2>Pupils</h2>
    <a href="view_table.php?table=Pupils">View Pupils</a>

    <h2>Parents/Guardians</h2>
    <a href="view_table.php?table=Parents">View Parents</a>

    <br><a href="index.php">Back to Home</a>
</body>
</html>
